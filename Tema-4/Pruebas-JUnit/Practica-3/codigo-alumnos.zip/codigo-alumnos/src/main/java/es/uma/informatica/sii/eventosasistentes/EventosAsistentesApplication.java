package es.uma.informatica.sii.eventosasistentes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EventosAsistentesApplication {

    public static void main(String[] args) {
        SpringApplication.run(EventosAsistentesApplication.class, args);
    }

}
